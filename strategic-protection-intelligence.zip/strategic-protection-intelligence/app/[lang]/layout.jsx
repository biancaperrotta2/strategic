import { notFound } from "next/navigation";
import { Montserrat } from "next/font/google";
import "../globals.css";
import { SITE, LOCALES } from "@/lib/site";
import { CONTENT } from "@/lib/content";

// Montserrat: la misma familia del logotipo, en toda la página.
const display = Montserrat({ subsets: ["latin"], weight: ["400", "500", "600", "700", "800"], variable: "--font-display", display: "swap" });

// Cada idioma es una URL propia (/es, /en): Google indexa ambas versiones.
export const dynamicParams = false;
export function generateStaticParams() {
  return LOCALES.map((lang) => ({ lang }));
}

export const viewport = {
  themeColor: "#030303",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export function generateMetadata({ params }) {
  const t = CONTENT[params.lang];
  if (!t) return {};
  const { title, description, keywords, ogAlt } = t.meta;
  return {
    metadataBase: new URL(SITE.url),
    title: { default: title, template: "%s | STRATEGIC" },
    description,
    keywords,
    applicationName: SITE.legalName,
    authors: [{ name: SITE.legalName }],
    creator: SITE.legalName,
    alternates: {
      canonical: `/${params.lang}`,
      languages: { "es-AR": "/es", en: "/en", "x-default": "/es" },
    },
    openGraph: {
      type: "website",
      locale: params.lang === "es" ? "es_AR" : "en_US",
      alternateLocale: params.lang === "es" ? ["en_US"] : ["es_AR"],
      url: `/${params.lang}`,
      siteName: SITE.legalName,
      title,
      description,
      images: [{ url: "/og.jpg", width: 1200, height: 630, alt: ogAlt }],
    },
    twitter: { card: "summary_large_image", title, description, images: ["/og.jpg"] },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 },
    },
    icons: { icon: "/favicon.ico", apple: "/apple-touch-icon.png" },
    category: "security",
  };
}

function jsonLd(lang) {
  const t = CONTENT[lang];
  const url = `${SITE.url}/${lang}`;
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${SITE.url}/#organization`,
        name: SITE.legalName,
        url: SITE.url,
        logo: `${SITE.url}/strategic/logo.webp`,
        email: SITE.email,
        telephone: SITE.phone,
        sameAs: SITE.social,
      },
      {
        "@type": "ProfessionalService",
        "@id": `${SITE.url}/#business`,
        name: SITE.legalName,
        description: t.meta.description,
        url,
        image: `${SITE.url}/og.jpg`,
        telephone: SITE.phone,
        email: SITE.email,
        priceRange: "$$$$",
        availableLanguage: ["es", "en"],
        address: {
          "@type": "PostalAddress",
          addressLocality: SITE.address.city,
          addressRegion: SITE.address.region,
          addressCountry: SITE.address.country,
        },
        areaServed: SITE.areaServed.map((name) => ({ "@type": "AdministrativeArea", name })),
        knowsAbout: ["ESRM", "CPTED", "Executive protection", "Countersurveillance", "Due diligence", "TVCA", "Cybersecurity"],
        parentOrganization: { "@id": `${SITE.url}/#organization` },
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: t.services.title,
          itemListElement: t.services.lines.map((line) => ({
            "@type": "OfferCatalog",
            name: line.title,
            itemListElement: line.items.map((s) => ({
              "@type": "Offer",
              itemOffered: { "@type": "Service", name: s.title, description: s.desc, areaServed: SITE.areaServed },
            })),
          })),
        },
      },
      { "@type": "WebSite", "@id": `${SITE.url}/#website`, url: SITE.url, name: SITE.legalName, inLanguage: ["es-AR", "en"], publisher: { "@id": `${SITE.url}/#organization` } },
    ],
  };
}

export default function RootLayout({ children, params }) {
  const t = CONTENT[params.lang];
  if (!t) notFound();
  return (
    <html lang={t.locale} className={display.variable}>
      <body className="bg-[#030303] font-sans text-stone-200 antialiased">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd(params.lang)).replace(/</g, "\\u003c") }} />
        {children}
      </body>
    </html>
  );
}
