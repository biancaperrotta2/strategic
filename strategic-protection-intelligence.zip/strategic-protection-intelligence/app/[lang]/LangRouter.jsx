"use client";
import { useCallback } from "react";
import { useRouter } from "next/navigation";
import { LangProvider } from "@/lib/i18n";

/** En Next.js, cambiar de idioma navega a /es o /en (sin perder el scroll). */
export default function LangRouter({ lang, children }) {
  const router = useRouter();
  const onChange = useCallback(
    (next) => {
      try { document.cookie = `lang=${next}; path=/; max-age=31536000; samesite=lax`; } catch {}
      router.push(`/${next}${window.location.hash}`, { scroll: false });
    },
    [router]
  );
  return <LangProvider lang={lang} onChange={onChange}>{children}</LangProvider>;
}
