import LangRouter from "./LangRouter";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import Plans from "@/components/Plans";
import Methodology from "@/components/Methodology";
import Company from "@/components/Company";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import { QuoteProvider } from "@/components/QuoteContext";

export default function Home({ params }) {
  return (
    <LangRouter lang={params.lang}>
      <QuoteProvider>
        <Navbar />
        <main>
          <Hero />
          <Services />
          <Plans />
          <Methodology />
          <Company />
        </main>
        <Footer />
        <WhatsAppButton />
      </QuoteProvider>
    </LangRouter>
  );
}
