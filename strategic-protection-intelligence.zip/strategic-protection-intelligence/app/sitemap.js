import { SITE, LOCALES } from "@/lib/site";

export default function sitemap() {
  const languages = { "es-AR": `${SITE.url}/es`, en: `${SITE.url}/en` };
  return LOCALES.map((l) => ({
    url: `${SITE.url}/${l}`,
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: l === "es" ? 1 : 0.9,
    alternates: { languages },
  }));
}
