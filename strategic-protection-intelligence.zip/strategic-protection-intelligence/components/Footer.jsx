"use client";
import { Mail, Phone, MapPin } from "lucide-react";
import Emblem from "./Emblem";
import { SITE } from "@/lib/site";
import { useLang } from "@/lib/i18n";

export default function Footer() {
  const { t } = useLang();
  return (
    <footer id="contacto" className="relative border-t border-amber-500/10 bg-[#030303]">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:grid-cols-[1.4fr_1fr]">
        <div className="flex items-start gap-4">
          <Emblem className="h-12 w-auto shrink-0 text-[#D9BC7A]" label="" />
          <div>
            <p className="font-display text-lg font-extrabold tracking-[0.03em] text-[#D9BC7A]">STRATEGIC</p>
            <p className="mt-1 font-display text-[11px] font-medium tracking-[0.18em] text-[#D9BC7A]/70">PROTECTION &amp; INTELLIGENCE</p>
            <p className="mt-4 max-w-sm font-display text-[15px] text-stone-400">{t.footer.blurb}</p>
          </div>
        </div>
        <address className="space-y-3 not-italic text-[14.5px] text-stone-400">
          <a href={`tel:${SITE.phone.replace(/\s/g, "")}`} className="flex items-center gap-3 hover:text-stone-100"><Phone className="h-4 w-4 text-[#C5A059]" aria-hidden />{SITE.phone}</a>
          <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 hover:text-stone-100"><Mail className="h-4 w-4 text-[#C5A059]" aria-hidden />{SITE.email}</a>
          <p className="flex items-center gap-3"><MapPin className="h-4 w-4 text-[#C5A059]" aria-hidden />{SITE.address.city}, {t.footer.country}</p>
          <p className="pt-2 font-display text-[11px] font-medium uppercase tracking-[0.18em] text-stone-600">Ley 9578 · DISEP</p>
        </address>
      </div>
      <p className="border-t border-white/5 py-6 text-center text-[12.5px] text-stone-600">
        © {new Date().getFullYear()} {SITE.legalName}. {t.footer.rights}
      </p>
    </footer>
  );
}
