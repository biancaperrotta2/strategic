"use client";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Check, Lock } from "lucide-react";
import LuxButton from "./LuxButton";
import { Button } from "./ui/stateful-button";
import { SITE } from "@/lib/site";
import { useLang } from "@/lib/i18n";

const TABS = ["meeting", "quote", "budget"];
const SPRING = { type: "spring", stiffness: 100, damping: 20 };
const field =
  "w-full rounded-[3px] border border-white/5 bg-white/[0.02] px-4 text-[15px] text-stone-100 placeholder:text-stone-500 transition-colors focus:border-amber-500/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/20";
const labelCls = "mb-1.5 block text-[13px] text-stone-300";

/** Control segmentado accesible (grupo de radios). */
function Segmented({ name, legend, options, value, onChange }) {
  return (
    <fieldset>
      <legend className={labelCls}>{legend}</legend>
      <div className="grid gap-1 rounded-[3px] border border-white/5 bg-white/[0.02] p-1" style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0,1fr))` }}>
        {options.map((o, i) => (
          <label key={o} className="relative cursor-pointer">
            <input type="radio" name={name} value={o} checked={value === i} onChange={() => onChange(i)} className="peer sr-only" />
            {value === i && <motion.span layoutId={`seg-${name}`} className="absolute inset-0 rounded-[2px] bg-amber-500/10 ring-1 ring-amber-500/40" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
            <span className={`relative flex h-10 items-center justify-center rounded-[2px] px-1 text-center text-[13.5px] transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-[#D4AF37] ${value === i ? "text-[#EADBB4]" : "text-stone-400"}`}>{o}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export default function QuoteModal({ open, initialTab = "meeting", initialPlan = null, onClose }) {
  const { t } = useLang();
  const m = t.modal;
  const [tab, setTab] = useState(initialTab);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState({});
  const [seg, setSeg] = useState({ mode: 0, slot: 0, risk: 1, term: 1 });
  const [linesSel, setLinesSel] = useState([]);
  const firstRef = useRef(null);
  const formRef = useRef(null);
  const sendRef = useRef(null);

  const services = [...t.services.lines.flatMap((l) => l.items.map((i) => i.title)), m.other];
  const plans = [...t.plans.items.map((p) => p.name), m.planCustom];
  const planDefault = initialPlan ? Math.max(0, t.plans.items.findIndex((p) => p.id === initialPlan)) : plans.length - 1;

  useEffect(() => {
    if (!open) return;
    setTab(initialTab);
    setSent(false);
    setErrors({});
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const tm = setTimeout(() => firstRef.current?.focus(), 80);
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      clearTimeout(tm);
      window.removeEventListener("keydown", onKey);
    };
  }, [open, initialTab, onClose]);

  const onTabKey = (e) => {
    const i = TABS.indexOf(tab);
    const next = e.key === "ArrowRight" ? (i + 1) % 3 : e.key === "ArrowLeft" ? (i + 2) % 3 : null;
    if (next === null) return;
    e.preventDefault();
    setTab(TABS[next]);
    document.getElementById(`tab-${TABS[next]}`)?.focus();
  };

  // Enter en cualquier campo dispara el mismo botón (y su animación).
  const submit = (e) => {
    e.preventDefault();
    sendRef.current?.click();
  };

  // false si no valida; si valida, abre WhatsApp en el mismo gesto del usuario.
  const send = () => {
    const d = Object.fromEntries(new FormData(formRef.current));
    const errs = {};
    if (!d.nombre?.trim()) errs.nombre = m.errName;
    if (!/^[+\d\s()-]{8,}$/.test(d.telefono || "")) errs.telefono = m.errPhone;
    setErrors(errs);
    if (Object.keys(errs).length) return false;

    const rows = [m.waTitle[tab], `${m.name}: ${d.nombre}`, `${m.phone}: ${d.telefono}`, d.email && `${m.email}: ${d.email}`];
    if (tab === "meeting") rows.push(`${m.mode}: ${m.modes[seg.mode]}`, d.fecha && `${m.date}: ${d.fecha}`, `${m.slot}: ${m.slots[seg.slot]}`, d.detalle && `${m.topic}: ${d.detalle}`);
    if (tab === "quote") rows.push(`${m.service}: ${d.servicio}`, d.fecha && `${m.eventDate}: ${d.fecha}`, `${m.risk} ${m.risks[seg.risk]}`, d.detalle && `${m.detail}: ${d.detalle}`);
    if (tab === "budget") rows.push(`${m.plan}: ${d.plan}`, linesSel.length && `${m.lines}: ${linesSel.map((i) => t.services.lines[i].title).join(", ")}`, `${m.term}: ${m.terms[seg.term]}`, d.detalle && `${m.detail}: ${d.detalle}`);

    window.open(`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(rows.filter(Boolean).join("\n"))}`, "_blank", "noopener,noreferrer");
    // Pausa deliberada para que el estado de carga se lea con calma.
    return new Promise((resolve) => setTimeout(resolve, 2200));
  };

  const setS = (k) => (v) => setSeg((s) => ({ ...s, [k]: v }));

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center sm:p-6">
          <motion.div className="absolute inset-0 bg-black/75 backdrop-blur-md" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="quote-title"
            className="relative max-h-[92svh] w-full max-w-lg overflow-y-auto rounded-t-lg border border-[#D4AF37]/15 bg-[#060606]/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-md sm:rounded-md"
            initial={{ opacity: 0, y: 40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.98, transition: { duration: 0.2 } }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            <div aria-hidden className="h-px w-full bg-gradient-to-r from-transparent via-[#D4AF37]/70 to-transparent" />
            <button type="button" onClick={onClose} aria-label={m.close} className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-[3px] border border-white/5 text-stone-400 transition-colors hover:text-white">
              <X className="h-4 w-4" aria-hidden />
            </button>

            <AnimatePresence mode="wait" initial={false}>
              {sent ? (
                <motion.div key="ok" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex flex-col items-center px-7 py-14 text-center">
                  <span className="flex h-14 w-14 items-center justify-center rounded-full border border-[#D4AF37]/40">
                    <Check className="h-6 w-6 text-[#D9BC7A]" strokeWidth={1.25} aria-hidden />
                  </span>
                  <h2 id="quote-title" className="mt-5 font-display text-[1.15rem] font-bold uppercase tracking-[0.03em] text-stone-100">{m.sentTitle}</h2>
                  <p className="mt-2 max-w-sm font-display text-[15px] text-stone-400">{m.sentText}</p>
                  <LuxButton className="mt-8" onClick={onClose}>{m.close}</LuxButton>
                </motion.div>
              ) : (
                <motion.form key="form" ref={formRef} noValidate onSubmit={submit} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-6 pb-7 pt-7 sm:px-8">
                  <h2 id="quote-title" className="pr-10 font-display text-[1.15rem] font-bold uppercase tracking-[0.03em] text-stone-100">{{ meeting: t.cta.meeting, quote: t.cta.quote, budget: t.cta.budget }[tab]}</h2>

                  {/* Pestañas */}
                  <div role="tablist" aria-label={m.tablist} onKeyDown={onTabKey} className="mt-5 grid grid-cols-3 border-b border-white/5">
                    {TABS.map((k) => {
                      const on = tab === k;
                      return (
                        <button
                          key={k}
                          id={`tab-${k}`}
                          type="button"
                          role="tab"
                          aria-selected={on}
                          aria-controls="tab-panel"
                          tabIndex={on ? 0 : -1}
                          onClick={() => setTab(k)}
                          className={`relative pb-3 font-display text-[11px] font-semibold uppercase tracking-[0.16em] transition-colors duration-300 ${on ? "text-[#EADBB4]" : "text-stone-500 hover:text-stone-300"}`}
                        >
                          {m.tabs[k]}
                          {on && <motion.span layoutId="modal-tab" aria-hidden className="absolute inset-x-0 -bottom-px h-px bg-[#D4AF37]" transition={SPRING} />}
                        </button>
                      );
                    })}
                  </div>

                  <div id="tab-panel" role="tabpanel" aria-labelledby={`tab-${tab}`}>
                    <p className="mt-4 font-display text-[14px] text-stone-400">{m.intro[tab]}</p>

                    <div className="mt-6 space-y-4">
                      <div>
                        <label htmlFor="q-nombre" className={labelCls}>{m.name}</label>
                        <input ref={firstRef} id="q-nombre" name="nombre" autoComplete="name" className={`${field} h-12`} aria-invalid={!!errors.nombre} aria-describedby={errors.nombre ? "e-nombre" : undefined} />
                        {errors.nombre && <p id="e-nombre" className="mt-1 text-[13px] text-amber-300">{errors.nombre}</p>}
                      </div>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                          <label htmlFor="q-tel" className={labelCls}>{m.phone}</label>
                          <input id="q-tel" name="telefono" type="tel" inputMode="tel" autoComplete="tel" placeholder="+54 9 …" className={`${field} h-12`} aria-invalid={!!errors.telefono} aria-describedby={errors.telefono ? "e-tel" : undefined} />
                          {errors.telefono && <p id="e-tel" className="mt-1 text-[13px] text-amber-300">{errors.telefono}</p>}
                        </div>
                        <div>
                          <label htmlFor="q-mail" className={labelCls}>{m.email} <span className="text-stone-500">{m.optional}</span></label>
                          <input id="q-mail" name="email" type="email" autoComplete="email" className={`${field} h-12`} />
                        </div>
                      </div>

                      <AnimatePresence mode="wait" initial={false}>
                        <motion.div key={tab} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, transition: { duration: 0.12 } }} transition={SPRING} className="space-y-4">
                          {tab === "meeting" && (
                            <>
                              <Segmented name="mode" legend={m.mode} options={m.modes} value={seg.mode} onChange={setS("mode")} />
                              <div className="grid gap-4 sm:grid-cols-2">
                                <div>
                                  <label htmlFor="q-fecha" className={labelCls}>{m.date}</label>
                                  <input id="q-fecha" name="fecha" type="date" className={`${field} h-12 [color-scheme:dark]`} />
                                </div>
                                <Segmented name="slot" legend={m.slot} options={m.slots} value={seg.slot} onChange={setS("slot")} />
                              </div>
                            </>
                          )}
                          {tab === "quote" && (
                            <>
                              <div className="grid gap-4 sm:grid-cols-2">
                                <div>
                                  <label htmlFor="q-serv" className={labelCls}>{m.service}</label>
                                  <select id="q-serv" name="servicio" className={`${field} h-12 [color-scheme:dark]`} defaultValue={services[0]}>
                                    {services.map((s) => <option key={s} className="bg-[#0A0A0A]">{s}</option>)}
                                  </select>
                                </div>
                                <div>
                                  <label htmlFor="q-fecha" className={labelCls}>{m.eventDate}</label>
                                  <input id="q-fecha" name="fecha" type="date" className={`${field} h-12 [color-scheme:dark]`} />
                                </div>
                              </div>
                              <Segmented name="risk" legend={m.risk} options={m.risks} value={seg.risk} onChange={setS("risk")} />
                            </>
                          )}
                          {tab === "budget" && (
                            <>
                              <div className="space-y-4">
                                <div>
                                  <label htmlFor="q-plan" className={labelCls}>{m.plan}</label>
                                  <select id="q-plan" name="plan" className={`${field} h-12 [color-scheme:dark]`} defaultValue={plans[planDefault]}>
                                    {plans.map((p) => <option key={p} className="bg-[#0A0A0A]">{p}</option>)}
                                  </select>
                                </div>
                                <Segmented name="term" legend={m.term} options={m.terms} value={seg.term} onChange={setS("term")} />
                              </div>
                              <fieldset>
                                <legend className={labelCls}>{m.lines}</legend>
                                <div className="grid gap-2 sm:grid-cols-2">
                                  {t.services.lines.map((l, i) => {
                                    const on = linesSel.includes(i);
                                    return (
                                      <label key={l.code} className={`flex cursor-pointer items-center gap-3 rounded-[3px] border px-3 py-2.5 text-[13.5px] transition-colors ${on ? "border-amber-500/40 bg-amber-500/[0.06] text-[#EADBB4]" : "border-white/5 text-stone-400 hover:text-stone-200"}`}>
                                        <input type="checkbox" checked={on} onChange={() => setLinesSel((s) => (on ? s.filter((x) => x !== i) : [...s, i]))} className="h-3.5 w-3.5 accent-[#D4AF37]" />
                                        {l.title}
                                      </label>
                                    );
                                  })}
                                </div>
                              </fieldset>
                            </>
                          )}
                          <div>
                            <label htmlFor="q-det" className={labelCls}>{tab === "meeting" ? m.topic : m.detail} <span className="text-stone-500">{m.optional}</span></label>
                            <textarea id="q-det" name="detalle" rows={3} placeholder={tab === "meeting" ? m.topicPh : m.detailPh} className={`${field} resize-none py-3`} />
                          </div>
                        </motion.div>
                      </AnimatePresence>
                    </div>
                  </div>

                  <Button ref={sendRef} onClick={send} onComplete={() => setSent(true)} successLabel={m.sentLabel} busyLabel={m.sending} className="mt-7 w-full">
                    {m.send}
                  </Button>
                  <p className="mt-3 flex items-center justify-center gap-1.5 text-[12.5px] text-stone-500">
                    <Lock className="h-3.5 w-3.5" aria-hidden /> {m.privacy}
                  </p>
                </motion.form>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
