"use client";
import { useId } from "react";
import { motion } from "framer-motion";
import { useLang } from "@/lib/i18n";
import { LOCALES } from "@/lib/site";

/** Selector de idioma siempre visible: ES · EN (escala a más idiomas). */
export default function LangToggle({ className = "" }) {
  const { lang, t, setLang } = useLang();
  const uid = useId();
  return (
    <div role="group" aria-label={t.lang.label} className={`flex items-center ${className}`}>
      {LOCALES.map((code, i) => {
        const on = code === lang;
        return (
          <span key={code} className="flex items-center">
            {i > 0 && <span aria-hidden className="mx-2 h-3 w-px bg-white/15" />}
            <button
              type="button"
              lang={code}
              aria-pressed={on}
              aria-label={t.lang.names[code]}
              onClick={() => setLang(code)}
              className={`relative py-1 font-display text-[11px] font-semibold uppercase tracking-[0.16em] transition-colors duration-500 ${on ? "text-[#D9BC7A]" : "text-stone-500 hover:text-stone-200"}`}
            >
              {code}
              {on && <motion.span layoutId={`lang-dot-${uid}`} aria-hidden className="absolute -bottom-0.5 left-0 right-[0.16em] h-px bg-[#D4AF37]/60" />}
            </button>
          </span>
        );
      })}
    </div>
  );
}
