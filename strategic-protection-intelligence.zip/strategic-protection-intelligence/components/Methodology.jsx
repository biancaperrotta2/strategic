"use client";
import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { useLang } from "@/lib/i18n";

const SPRING = { type: "spring", stiffness: 100, damping: 20 };

export default function Methodology() {
  const reduce = useReducedMotion();
  const { t } = useLang();
  const c = t.method;
  const OPORD = c.opord;
  const PACE = c.pace;
  const [pace, setPace] = useState(0);
  const reveal = (delay = 0) => ({
    initial: reduce ? false : { opacity: 0, y: 14 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-80px" },
    transition: { ...SPRING, delay },
  });

  return (
    <section id="metodologia" aria-labelledby="metodologia-title" className="relative border-t border-white/5">
      <div className="mx-auto max-w-6xl px-5 py-24 sm:py-32">
        <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]/80">{c.eyebrow}</p>
        <h2 id="metodologia-title" className="mt-5 max-w-3xl font-display text-[clamp(1.5rem,3.4vw,2.4rem)] font-bold uppercase leading-[1.15] tracking-[0.03em] text-stone-100">
          {c.title}
        </h2>
        <p className="mt-6 max-w-xl font-display text-[16px] leading-relaxed text-stone-400">
          {c.lead}
        </p>

        {/* OPORD: cinco fases que se revelan con el scroll */}
        <ol className="relative mt-16 border-l border-white/5 pl-8 sm:pl-12">
          <motion.span
            aria-hidden
            className="absolute -left-px top-0 h-full w-px origin-top bg-gradient-to-b from-[#D4AF37]/60 via-[#D4AF37]/25 to-transparent"
            initial={reduce ? false : { scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
          />
          {OPORD.map((step, k) => (
            <motion.li key={step.title} {...reveal(k * 0.08)} className="relative grid gap-3 py-7 sm:grid-cols-[4rem_15rem_1fr] sm:items-baseline sm:gap-8">
              <span aria-hidden className="absolute -left-[calc(2rem+3px)] top-[2.35rem] h-[5px] w-[5px] rotate-45 bg-[#D9BC7A] sm:-left-[calc(3rem+3px)]" />
              <span className="font-display text-[11px] font-medium tracking-[0.18em] text-[#D9BC7A]/70">{String(k + 1).padStart(2, "0")}</span>
              <h3 className="font-display text-[12px] font-semibold uppercase tracking-[0.18em] text-stone-100">{step.title}</h3>
              <p className="font-display text-[15px] leading-relaxed text-stone-400">{step.desc}</p>
            </motion.li>
          ))}
        </ol>

        {/* PACE: continuidad operativa */}
        <div className="mt-28 grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-20">
          <motion.div {...reveal()}>
            <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]/80">{c.paceEyebrow}</p>
            <h3 className="mt-5 font-display text-[clamp(1.35rem,2.8vw,2rem)] font-bold uppercase leading-[1.15] tracking-[0.03em] text-stone-100">{c.paceTitle}</h3>
            <p className="mt-6 max-w-md font-display text-[16px] leading-relaxed text-stone-400">
              {c.paceLead}
            </p>
          </motion.div>

          <motion.div {...reveal(0.1)}>
            <div role="group" aria-label={c.paceGroup} className="flex justify-between border-b border-white/5">
              {PACE.map((p, k) => {
                const on = pace === k;
                return (
                  <button
                    key={p.letter}
                    type="button"
                    aria-pressed={on}
                    aria-label={`${p.letter}: ${p.word}`}
                    onPointerEnter={(e) => e.pointerType === "mouse" && setPace(k)}
                    onFocus={() => setPace(k)}
                    onClick={() => setPace(k)}
                    className="relative flex-1 pb-5 text-center font-display text-[clamp(3rem,8vw,5.5rem)] font-extrabold leading-none"
                  >
                    <motion.span className="inline-block" animate={{ color: on ? "#D9BC7A" : "#3a3631" }} transition={SPRING}>
                      {p.letter}
                    </motion.span>
                    {on && <motion.span layoutId="pace-rule" aria-hidden className="absolute inset-x-[28%] -bottom-px h-px bg-[#D4AF37]" transition={SPRING} />}
                  </button>
                );
              })}
            </div>
            {/* Alto fijo: el cambio de nivel no mueve nada alrededor */}
            <div className="relative h-32 sm:h-28" aria-live="polite">
              <AnimatePresence initial={false}>
                <motion.div
                  key={pace}
                  className="absolute inset-x-0 top-0 pt-7"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, transition: { duration: 0.15 } }}
                  transition={SPRING}
                >
                  <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]">{PACE[pace].word}</p>
                  <p className="mt-3 font-display text-[16px] leading-relaxed text-stone-300">{PACE[pace].desc}</p>
                </motion.div>
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
