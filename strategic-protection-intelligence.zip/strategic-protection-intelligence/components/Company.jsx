"use client";
import { useLang } from "@/lib/i18n";

export default function Company() {
  const { t } = useLang();
  const c = t.company;
  return (
    <section id="empresa" aria-labelledby="empresa-title" className="relative border-t border-white/5">
      <div className="mx-auto max-w-6xl px-5 py-24 sm:py-32">
        <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]/80">{c.eyebrow}</p>
        <h2 id="empresa-title" className="mt-5 max-w-3xl font-display text-[clamp(1.5rem,3.4vw,2.4rem)] font-bold uppercase leading-[1.15] tracking-[0.03em] text-stone-100">
          {c.title}
        </h2>

        <h3 className="sr-only">{c.valuesLabel}</h3>
        <ul className="mt-14 grid grid-cols-2 border-t border-white/5 sm:grid-cols-3 lg:grid-cols-5">
          {c.values.map((v) => (
            <li key={v.title} className="border-b border-white/5 py-8 pr-6 lg:border-b-0 lg:border-r lg:px-6 lg:first:pl-0 lg:last:border-r-0">
              <p className="font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-stone-100">{v.title}</p>
              <p className="mt-3 font-display text-[15px] text-stone-500">{v.desc}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
