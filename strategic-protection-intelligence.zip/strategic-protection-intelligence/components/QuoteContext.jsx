"use client";
import { createContext, useCallback, useContext, useMemo, useState } from "react";
import QuoteModal from "./QuoteModal";

const Ctx = createContext({ openRequest: () => {}, openQuote: () => {}, openMeeting: () => {} });

/** Un solo modal con tres pestañas: reunión, cotización y presupuesto. */
export function QuoteProvider({ children }) {
  const [state, setState] = useState({ open: false, tab: "meeting", plan: null });
  const openRequest = useCallback((tab = "meeting", plan = null) => setState({ open: true, tab, plan }), []);
  const close = useCallback(() => setState((s) => ({ ...s, open: false })), []);
  const value = useMemo(
    () => ({ openRequest, openQuote: () => openRequest("quote"), openMeeting: () => openRequest("meeting") }),
    [openRequest]
  );
  return (
    <Ctx.Provider value={value}>
      {children}
      <QuoteModal open={state.open} initialTab={state.tab} initialPlan={state.plan} onClose={close} />
    </Ctx.Provider>
  );
}

export const useQuote = () => useContext(Ctx);
