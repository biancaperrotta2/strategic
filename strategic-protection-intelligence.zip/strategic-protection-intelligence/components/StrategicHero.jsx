"use client";
import { useEffect, useRef, useState } from "react";

/*
 * StrategicHero — intro animada del logo (escudo, espada, pluma y nombre).
 * Coreografía original intacta; integración para producción:
 *  - assets en WebP (868 KB → 187 KB) y `assets` opcional para resolver URLs
 *  - `fitHeight` / `anchorY` para dejar lugar a los CTA debajo del logo
 *  - el campo de partículas se pausa fuera de pantalla y queda estático con
 *    prefers-reduced-motion
 *  - los children se montan en una capa absoluta sobre todo el hero
 */

/* Piezas del logo: coordenadas en el espacio original de 1080×1086 */
const P = {
  shieldL: { x: 281, y: 140, w: 252, h: 629 },
  shieldR: { x: 529, y: 141, w: 252, h: 628 },
  sword: { x: 470, y: 32, w: 124, h: 704 },
  feather: { x: 333, y: 45, w: 444, h: 648 },
  L0: { x: 96, y: 783, w: 99, h: 122 },
  L1: { x: 198, y: 784, w: 92, h: 120 },
  L2: { x: 295, y: 783, w: 225, h: 122 },
  L3: { x: 503, y: 783, w: 95, h: 122 },
  L4: { x: 603, y: 782, w: 87, h: 123 },
  L5: { x: 691, y: 782, w: 115, h: 125 },
  L6: { x: 815, y: 783, w: 35, h: 122 },
  L7: { x: 855, y: 781, w: 112, h: 126 },
  sub: { x: 152, y: 926, w: 762, h: 43 },
};
const NAMES = [...Object.keys(P), "logo"];

const LW = 1080, LH = 1190; // logo + área de partículas
const CENTER_X = 531;
const GOLD = "#c9a96a";
const LIGHT = "#e9e9ed";

/* Línea de tiempo (segundos) */
const CUE = { escudo: 0, espada: 1.8, nombre: 3.4, destello: 6.0, end: 7.6 };

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const ease = {
  outCubic: (t) => 1 - Math.pow(1 - t, 3),
  inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  inOutSine: (t) => -(Math.cos(Math.PI * t) - 1) / 2,
  inExpo: (t) => (t === 0 ? 0 : Math.pow(2, 10 * t - 10)),
};
const anim = (from, to, start, dur, e = ease.outCubic) => (t) => from + (to - from) * e(clamp((t - start) / dur, 0, 1));
const mix = (c, pct) => `color-mix(in oklch, ${c} ${pct}%, transparent)`;

function Piece({ name, src, dx = 0, dy = 0, rot = 0, sc = 1, op = 1, blur = 0, style }) {
  const m = P[name];
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src(name)} alt="" draggable={false} decoding="async"
      style={{
        position: "absolute", left: m.x, top: m.y, width: m.w, height: m.h, display: "block",
        transform: `translate(${dx}px, ${dy}px) rotate(${rot}deg) scale(${sc})`, opacity: op,
        filter: blur > 0.2 ? `blur(${blur}px)` : "none", willChange: "transform, opacity", userSelect: "none",
        ...style,
      }}
    />
  );
}

const SPARKS = Array.from({ length: 26 }, (_, i) => ({
  a: (i / 26) * Math.PI * 2 + Math.sin(i * 12.9) * 0.2,
  len: 40 + (Math.sin(i * 7.3) * 0.5 + 0.5) * 80,
  dist: 220 + (Math.sin(i * 3.1) * 0.5 + 0.5) * 360,
}));
const LETTERS = ["L0", "L1", "L2", "L3", "L4", "L5", "L6", "L7"].map((n) => {
  const c = P[n].x + P[n].w / 2;
  return { n, side: c < CENTER_X ? -1 : 1, d: Math.abs(c - CENTER_X) };
});
const ORDER = [...LETTERS].sort((a, b) => a.d - b.d).map((o) => o.n);

/* Campo de partículas — canvas; se pausa fuera de pantalla */
function Sparkles({ density, color, still }) {
  const ref = useRef(null);
  useEffect(() => {
    const cv = ref.current;
    const ctx = cv.getContext("2d");
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const Wc = 960, Hc = 190;
    cv.width = Wc * dpr; cv.height = Hc * dpr; ctx.scale(dpr, dpr);
    const pts = Array.from({ length: density }, () => ({
      x: Math.random() * Wc, y: Math.random() * Hc, r: 0.6 + Math.random() * 1.5,
      sp: 1.2 + Math.random() * 3, ph: Math.random() * 6.28, dr: Math.random() * 6.28,
    }));
    let raf = 0;
    const t0 = performance.now();
    const frame = (t) => {
      ctx.clearRect(0, 0, Wc, Hc);
      ctx.fillStyle = color;
      for (const p of pts) {
        const tw = Math.sin(t * p.sp + p.ph);
        if (tw <= 0) continue;
        ctx.globalAlpha = tw;
        ctx.beginPath();
        ctx.arc(p.x + Math.sin(t * 0.6 + p.dr) * 8, p.y + Math.cos(t * 0.5 + p.dr) * 6, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    const loop = () => { frame((performance.now() - t0) / 1000); raf = requestAnimationFrame(loop); };
    if (still) { frame(1.3); return; }
    const io = new IntersectionObserver(([e]) => {
      cancelAnimationFrame(raf);
      if (e.isIntersecting) loop();
    });
    io.observe(cv);
    return () => { cancelAnimationFrame(raf); io.disconnect(); };
  }, [density, color, still]);
  const mask = "radial-gradient(ellipse 480px 190px at 50% 0%, #000 20%, transparent 100%)";
  return <canvas ref={ref} aria-hidden style={{ position: "absolute", inset: 0, width: "100%", height: "100%", WebkitMaskImage: mask, maskImage: mask }} />;
}

export default function StrategicHero({
  assetBase = "/strategic",
  ext = "webp",
  assets, // opcional: { shieldL: url, ... } — tiene prioridad sobre assetBase
  lineColor = "#cfd3e5",
  particles = 400,
  delay = 0.2,
  fitWidth = 0.88,
  fitHeight = 0.8,
  anchorY = 0.5,
  onComplete,
  id,
  className,
  style,
  children,
}) {
  const boxRef = useRef(null);
  const [scale, setScale] = useState(0);
  const [t, setT] = useState(0);
  const [reduce, setReduce] = useState(false);
  const doneRef = useRef(false);
  const src = (n) => assets?.[n] ?? `${assetBase}/${n}.${ext}`;

  // ajusta el logo al contenedor
  useEffect(() => {
    const el = boxRef.current;
    const ro = new ResizeObserver(([e]) => {
      const { width, height } = e.contentRect;
      setScale(Math.min((width * fitWidth) / LW, (height * fitHeight) / LH));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [fitWidth, fitHeight]);

  // precarga las piezas y reproduce la intro una sola vez
  useEffect(() => {
    let raf = 0, cancelled = false;
    const rm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setReduce(rm);
    Promise.all(NAMES.map((n) => new Promise((res) => { const i = new Image(); i.onload = i.onerror = res; i.src = src(n); })))
      .then(() => {
        if (cancelled) return;
        if (rm) { setT(CUE.end + 1); return; }
        const t0 = performance.now() + delay * 1000;
        const tick = () => {
          const now = Math.max(0, (performance.now() - t0) / 1000);
          setT(now);
          if (now < CUE.end + 0.5) raf = requestAnimationFrame(tick);
        };
        tick();
      });
    return () => { cancelled = true; cancelAnimationFrame(raf); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assetBase, ext, assets, delay]);

  useEffect(() => {
    if (!doneRef.current && t >= CUE.destello) { doneRef.current = true; onComplete?.(); }
  }, [t, onComplete]);

  /* ---- coreografía ---- */
  const meet = CUE.escudo + 1.3;
  const slide = anim(1, 0, 0.1, meet - 0.1, ease.inOutCubic)(t);
  const recoil = t > meet ? Math.sin((t - meet) * 26) * 9 * Math.exp(-(t - meet) * 7) : 0;
  const shDx = slide * 1500 + Math.abs(recoil);
  const shOp = anim(0, 1, 0.1, 0.5)(t);
  const seam = t > meet ? Math.exp(-(t - meet) * 4) : 0;

  const fS = CUE.escudo + 1.1, fE = CUE.espada + 0.7;
  const fx = anim(1, 0, fS, fE - fS, ease.outCubic)(t), fy = anim(1, 0, fS, fE - fS, ease.inOutSine)(t);

  const a = CUE.espada, imp = a + 1.15;
  const swY = t < a + 0.7 ? anim(-1300, -330, a + 0.05, 0.65)(t)
    : t < a + 0.95 ? anim(-330, -390, a + 0.7, 0.25, ease.inOutSine)(t)
    : anim(-390, 0, a + 0.95, 0.2, ease.inExpo)(t);
  const swBlur = t > imp - 0.2 && t < imp ? 5 : 0;

  const k = t - imp;
  const shake = k > 0 && k < 0.7 ? Math.sin(k * 75) * 16 * Math.exp(-k * 8) : 0;
  const flash = k > 0 ? Math.exp(-k * 5) : 0;
  const ring = anim(0, 1, imp, 0.9)(t), sp = anim(0, 1, imp, 0.7)(t);
  const glow = anim(0, 1, imp, 1.2)(t);

  const subS = CUE.nombre + 1.15;
  const subClip = anim(50, 0, subS, 0.9)(t);

  const shineS = CUE.destello + 0.3;
  const shineX = anim(-25, 125, shineS, 1.3, ease.inOutSine)(t);
  const line = anim(0, 1, CUE.destello, 0.9)(t);
  const field = anim(0, 1, CUE.destello + 0.25, 1.1)(t);
  const IMPX = CENTER_X, IMPY = 222;

  const bar = (wPct, h, color, blur) => (
    <div style={{ position: "absolute", left: `${(100 - wPct) / 2}%`, top: 0, width: `${wPct}%`, height: h, transform: `scaleX(${line})`,
      background: `linear-gradient(to right, transparent, ${color}, transparent)`, filter: blur ? "blur(3px)" : "none" }} />
  );

  return (
    <section ref={boxRef} id={id} className={className} aria-label="Strategic — Protection & Intelligence"
      style={{ position: "relative", width: "100%", height: "100svh", minHeight: 520, background: "#000", overflow: "hidden", ...style }}>
      <div aria-hidden style={{ position: "absolute", left: "50%", top: `${anchorY * 100}%`, width: LW, height: LH, opacity: scale ? 1 : 0,
        transform: `translate(-50%, -50%) translate(${shake * 0.6 * scale}px, ${shake * scale}px) scale(${scale})` }}>
        <div style={{ position: "absolute", left: CENTER_X - 900, top: 400 - 900, width: 1800, height: 1800, opacity: glow * 0.55,
          background: `radial-gradient(circle, ${mix(GOLD, 22)}, transparent 55%)`, pointerEvents: "none" }} />

        <Piece src={src} name="shieldL" dx={-shDx} rot={-slide * 10} op={shOp} blur={slide * 10} />
        <Piece src={src} name="shieldR" dx={shDx} rot={slide * 10} op={shOp} blur={slide * 10} />
        <div style={{ position: "absolute", left: CENTER_X - 4, top: 120, width: 8, height: 660, opacity: seam, borderRadius: 4,
          background: `linear-gradient(to bottom, transparent, ${GOLD} 15%, ${LIGHT} 50%, ${GOLD} 85%, transparent)`, boxShadow: `0 0 50px 14px ${mix(GOLD, 60)}` }} />

        {swBlur > 0 && <Piece src={src} name="sword" dy={swY - 160} op={0.25} blur={10} />}
        <Piece src={src} name="sword" dy={swY} op={t < a ? 0 : 1} blur={swBlur} />

        <Piece src={src} name="feather" dx={fx * 1250} dy={-fy * 440} rot={fx * 38} sc={1 - fx * 0.08} op={anim(0, 1, fS, 0.5)(t)} blur={fx * 8} />

        {LETTERS.map((o) => {
          const st = CUE.nombre + ORDER.indexOf(o.n) * 0.08;
          const u = anim(1, 0, st, 0.75)(t);
          return <Piece key={o.n} src={src} name={o.n} dx={o.side * u * 1050} op={anim(0, 1, st, 0.35)(t)} blur={u * 14} sc={1 + u * 0.15} />;
        })}
        <Piece src={src} name="sub" op={anim(0, 1, subS, 0.6)(t)} sc={anim(1.08, 1, subS, 1)(t)} style={{ clipPath: `inset(0 ${subClip}% 0 ${subClip}%)` }} />

        {shineX > -25 && shineX < 125 && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={src("logo")} alt="" style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1086,
            filter: "brightness(1.9)", opacity: 0.8, clipPath: `polygon(${shineX - 5}% 0, ${shineX + 5}% 0, ${shineX - 7}% 100%, ${shineX - 17}% 100%)` }} />
        )}

        <div style={{ position: "absolute", left: CENTER_X - 480, top: 985, width: 960, height: 190, opacity: t >= CUE.destello ? 1 : 0 }}>
          {bar(75, 3, lineColor, true)}{bar(75, 1, lineColor)}{bar(25, 6, LIGHT, true)}{bar(25, 1, LIGHT)}
          <div style={{ position: "absolute", inset: 0, opacity: field }}>
            {t >= CUE.destello && <Sparkles density={particles} color={LIGHT} still={reduce} />}
          </div>
        </div>

        {k > 0 && k < 1.6 && (
          <div style={{ position: "absolute", inset: -600, pointerEvents: "none" }}>
            <div style={{ position: "absolute", left: 600 + IMPX - 700, top: 600 + IMPY - 700, width: 1400, height: 1400, opacity: flash,
              background: `radial-gradient(circle, ${mix(LIGHT, 85)}, ${mix(GOLD, 45)} 12%, transparent 45%)` }} />
            <svg width={LW + 1200} height={LH + 1200} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
              <g transform="translate(600 600)">
                <ellipse cx={IMPX} cy={IMPY} rx={50 + ring * 860} ry={(50 + ring * 860) * 0.42} fill="none" stroke={GOLD} strokeWidth={3.5 - ring * 2.8} opacity={(1 - ring) * 0.9} />
                <ellipse cx={IMPX} cy={IMPY} rx={30 + ring * 500} ry={(30 + ring * 500) * 0.42} fill="none" stroke={LIGHT} strokeWidth="1.4" opacity={(1 - ring) * 0.6} />
                {SPARKS.map((s, i) => {
                  const d = 28 + sp * s.dist, l = s.len * (1 - sp);
                  const cx = Math.cos(s.a), cy = Math.sin(s.a) * 0.75 + sp * sp * 0.4;
                  return <line key={i} x1={IMPX + cx * d} y1={IMPY + cy * d} x2={IMPX + cx * (d + l)} y2={IMPY + cy * (d + l)}
                    stroke={i % 3 ? GOLD : LIGHT} strokeWidth="2.8" strokeLinecap="round" opacity={1 - sp} />;
                })}
              </g>
            </svg>
          </div>
        )}
      </div>
      {children && <div style={{ position: "absolute", inset: 0, zIndex: 2, pointerEvents: "none" }}>{children}</div>}
    </section>
  );
}
