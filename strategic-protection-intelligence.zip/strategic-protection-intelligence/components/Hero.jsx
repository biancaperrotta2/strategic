"use client";
import { useCallback, useState } from "react";
import { motion } from "framer-motion";
import StrategicHero from "./StrategicHero";
import LuxButton from "./LuxButton";
import { useQuote } from "./QuoteContext";
import { markIntroDone } from "@/lib/intro";
import { useLang } from "@/lib/i18n";

const SPRING = { type: "spring", stiffness: 100, damping: 20 };

export default function Hero({ assets }) {
  const { openQuote, openMeeting } = useQuote();
  const { t } = useLang();
  const [done, setDone] = useState(false);
  const onComplete = useCallback(() => {
    setDone(true);
    markIntroDone();
  }, []);
  const show = (delay) => ({
    initial: { opacity: 0, y: 10 },
    animate: done ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 },
    transition: { ...SPRING, delay },
  });

  return (
    <StrategicHero
      id="inicio"
      assets={assets}
      fitHeight={0.6}
      anchorY={0.42}
      onComplete={onComplete}
      style={{ background: "#030303", minHeight: 600 }}
    >
      <h1 className="sr-only">
        {t.hero.h1}
      </h1>

      <div className="pointer-events-auto absolute inset-x-0 bottom-[calc(2.25rem+env(safe-area-inset-bottom))] flex flex-col items-center px-5">
        <motion.p {...show(0.6)} className="max-w-[30rem] text-center font-display [@media(max-height:700px)]:hidden text-[15px] leading-relaxed text-stone-400 sm:text-[17px]">
          {t.hero.tagline}
        </motion.p>
        <motion.div {...show(0.85)} className="mt-7 flex flex-col items-center gap-5 sm:flex-row sm:gap-12">
          <LuxButton onClick={openMeeting} tabIndex={done ? 0 : -1}>{t.cta.meeting}</LuxButton>
          <button
            type="button"
            onClick={openQuote}
            tabIndex={done ? 0 : -1}
            className="group relative py-2 font-display text-[11px] font-medium uppercase tracking-[0.16em] text-stone-300 transition-colors duration-500 hover:text-white"
          >
            {t.cta.quote}
            <span aria-hidden className="absolute bottom-0 left-0 h-px w-full origin-left scale-x-[0.35] bg-[#D4AF37]/50 transition-transform duration-700 ease-out group-hover:scale-x-100" />
          </button>
        </motion.div>
      </div>
    </StrategicHero>
  );
}
