"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, Lock } from "lucide-react";
import { SITE } from "@/lib/site";
import { useIntroDone } from "@/lib/intro";
import { useLang } from "@/lib/i18n";

export default function WhatsAppButton() {
  const [hover, setHover] = useState(false);
  const introDone = useIntroDone();
  const { t } = useLang();
  const href = `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(t.wa.text)}`;

  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t.wa.aria}
      onHoverStart={() => setHover(true)}
      onHoverEnd={() => setHover(false)}
      onFocus={() => setHover(true)}
      onBlur={() => setHover(false)}
      initial={{ opacity: 0, scale: 0.6, y: 20 }}
      animate={introDone ? { opacity: 1, scale: 1, y: 0 } : { opacity: 0, scale: 0.6, y: 20 }}
      transition={{ delay: introDone ? 1.2 : 0, type: "spring", stiffness: 260, damping: 20 }}
      tabIndex={introDone ? 0 : -1}
      style={{ pointerEvents: introDone ? "auto" : "none" }}
      className="fixed bottom-[calc(1.25rem+env(safe-area-inset-bottom))] right-4 z-50 flex h-14 items-center rounded-full border border-white/5 bg-[#030303]/60 p-2 backdrop-blur-md sm:right-6"
    >
      <span className="relative flex h-10 w-10 items-center justify-center rounded-full border border-[#D4AF37]/30 bg-white/5">
        <MessageCircle className="h-5 w-5 text-[#D9BC7A]" strokeWidth={1.5} aria-hidden />
        <span className="absolute -bottom-0.5 -right-0.5 flex h-[18px] w-[18px] items-center justify-center rounded-full border border-[#D4AF37]/60 bg-[#050505]">
          <Lock className="h-2.5 w-2.5 text-[#D4AF37]" aria-hidden />
        </span>
      </span>
      <AnimatePresence initial={false}>
        {hover && (
          <motion.span
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: "auto", opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden whitespace-nowrap"
          >
            <span className="block px-3 font-display text-[11px] font-medium uppercase tracking-[0.16em] text-stone-100">{t.wa.label}</span>
          </motion.span>
        )}
      </AnimatePresence>
    </motion.a>
  );
}
