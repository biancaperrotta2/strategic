"use client";
import { motion, useReducedMotion } from "framer-motion";

const EASE = [0.22, 1, 0.36, 1];

/** Escudo + espada + pluma en un solo tono (currentColor). Con `assemble` se ensambla al cargar. */
export default function Emblem({ className = "", assemble = false, label = "Emblema de STRATEGIC: escudo, espada y pluma" }) {
  const reduce = useReducedMotion();
  const on = assemble && !reduce;

  return (
    <svg viewBox="0 0 200 240" className={className} role={label ? "img" : undefined} aria-label={label || undefined} aria-hidden={label ? undefined : true}>
      <motion.path
        d="M86 30 H42 L20 52 V150 L100 226 L180 150 V52 L158 30 H114"
        fill="none" stroke="currentColor" strokeWidth="5"
        initial={on ? { pathLength: 0, opacity: 0 } : false}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 1.6, ease: [0.65, 0, 0.35, 1] }}
      />
      <motion.g
        fill="currentColor"
        initial={on ? { y: -50, opacity: 0 } : false}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 1.1, ease: EASE }}
      >
        <circle cx="100" cy="12" r="7" fill="none" stroke="currentColor" strokeWidth="3.5" />
        <rect x="97" y="19" width="6" height="32" rx="2" />
        <path d="M78 51 H122 L118 57 H82 Z" />
        <path d="M96 57 H104 L100 216 Z" />
      </motion.g>
      <motion.g
        initial={on ? { x: 30, y: -20, rotate: 14, opacity: 0 } : false}
        animate={{ x: 0, y: 0, rotate: 0, opacity: 1 }}
        transition={{ delay: 0.9, duration: 1.2, ease: EASE }}
      >
        <path d="M74 198 C78 150 104 92 160 26 C158 86 136 134 96 168 C88 176 80 186 74 198 Z" fill="currentColor" />
        <path d="M74 198 C96 150 126 92 160 26" fill="none" stroke="#030303" strokeWidth="2" strokeLinecap="round" />
        <path d="M84 168 l-9 3 M95 148 l-9 2 M108 126 l-8 1" stroke="#030303" strokeWidth="2.4" strokeLinecap="round" />
      </motion.g>
    </svg>
  );
}
