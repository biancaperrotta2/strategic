"use client";
import { forwardRef, useRef, useState } from "react";
import { motion, AnimatePresence, useAnimate } from "framer-motion";

/**
 * Stateful Button (API de Aceternity): muestra un loader mientras `onClick`
 * resuelve y un check al terminar.
 * Diferencias con el original, pensadas para un formulario real:
 *  - `onClick` se ejecuta en el mismo gesto del usuario (antes de animar), así
 *    un window.open (WhatsApp) no lo bloquea el navegador.
 *  - Si `onClick` devuelve `false` (p. ej. validación fallida) no hay éxito;
 *    si lanza un error, el botón hace un leve "no" y se rehabilita.
 *  - `onComplete` se llama cuando el check ya se mostró.
 *  - Bloquea doble clic y anuncia el estado a lectores de pantalla.
 */
export const Button = forwardRef(function Button({ children, className = "", onClick, onComplete, successLabel = "Enviado", busyLabel = "Enviando…", ...props }, ref) {
  const [scope, animate] = useAnimate();
  const setRefs = (el) => {
    scope.current = el;
    if (typeof ref === "function") ref(el);
    else if (ref) ref.current = el;
  };
  const [status, setStatus] = useState("idle"); // idle | loading | success
  const busy = useRef(false);

  // Tiempos pensados para que cada estado se lea: entrada suave, check sostenido.
  const show = (sel) => animate(sel, { width: "20px", scale: 1, opacity: 1 }, { duration: 0.5, ease: [0.22, 1, 0.36, 1] });
  const hide = (sel) => animate(sel, { width: "0px", scale: 0, opacity: 0 }, { duration: 0.4, ease: [0.4, 0, 0.2, 1] });

  const handleClick = async (event) => {
    if (busy.current) return;
    busy.current = true;
    let work;
    try {
      work = onClick?.(event); // sincrónico: corre dentro del gesto del usuario
    } catch (err) {
      work = Promise.reject(err);
    }

    // Validación sincrónica fallida: no hay estado de carga.
    if (work === false) {
      busy.current = false;
      return;
    }

    setStatus("loading");
    try {
      const [result] = await Promise.all([work, show(".sb-loader")]);
      await hide(".sb-loader");
      if (result === false) throw new Error("cancelled");
      setStatus("success");
      await show(".sb-check");
      await new Promise((r) => setTimeout(r, 1600));
      onComplete?.();
      await hide(".sb-check");
    } catch {
      await hide(".sb-loader");
      await animate(scope.current, { x: [0, -5, 5, -3, 3, 0] }, { duration: 0.4 });
    } finally {
      setStatus("idle");
      busy.current = false;
    }
  };

  return (
    <motion.button
      ref={setRefs}
      layout
      type="button"
      aria-busy={status === "loading"}
      aria-live="polite"
      disabled={status !== "idle"}
      onClick={handleClick}
      className={`inline-flex h-12 min-w-[120px] items-center justify-center rounded-[2px] border border-[#D4AF37]/30 bg-white/5 px-9 font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-[#EADBB4] backdrop-blur-md transition-[background-color,border-color,color] duration-500 hover:border-[#D4AF37]/60 hover:bg-[#D4AF37]/[0.08] hover:text-white disabled:cursor-wait ${className}`}
      {...props}
    >
      <motion.span layout className="flex items-center gap-3">
        <Loader />
        <CheckIcon />
        {/* El texto también cambia de estado, para que el proceso se note */}
        <motion.span layout className="relative flex items-center gap-2.5">
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={status}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.3 }}
              className="flex items-center gap-2.5"
            >
              {status === "loading" ? busyLabel : status === "success" ? successLabel : children}
            </motion.span>
          </AnimatePresence>
        </motion.span>
      </motion.span>
    </motion.button>
  );
});

const iconStyle = { width: 0, transform: "scale(0)", opacity: 0 };

function Loader() {
  return (
    <motion.svg
      aria-hidden
      className="sb-loader shrink-0 text-[#D9BC7A]"
      style={iconStyle}
      viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
      animate={{ rotate: 360 }}
      transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
    >
      <path d="M12 3a9 9 0 1 0 9 9" />
    </motion.svg>
  );
}

function CheckIcon() {
  return (
    <svg aria-hidden className="sb-check shrink-0 text-[#D9BC7A]" style={iconStyle} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9" opacity="0.5" />
      <path d="M8.5 12.5l2.5 2.5 4.5-5" />
    </svg>
  );
}
