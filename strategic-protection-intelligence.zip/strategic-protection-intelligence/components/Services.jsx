"use client";
import { useLang } from "@/lib/i18n";

export default function Services() {
  const { t } = useLang();
  const c = t.services;
  return (
    <section id="servicios" aria-labelledby="servicios-title" className="relative mx-auto max-w-6xl px-5 py-24 sm:py-32">
      <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]/80">{c.eyebrow}</p>
      <h2 id="servicios-title" className="mt-5 max-w-3xl font-display text-[clamp(1.5rem,3.4vw,2.4rem)] font-bold uppercase leading-[1.15] tracking-[0.03em] text-stone-100">
        {c.title}
      </h2>
      <p className="mt-6 max-w-xl font-display text-[16px] leading-relaxed text-stone-400">
        {c.lead}
      </p>

      <div className="mt-16">
        {c.lines.map((line) => (
          <article key={line.code} aria-labelledby={`linea-${line.code}`} className="grid gap-10 border-t border-white/5 py-14 lg:grid-cols-[21rem_1fr] lg:gap-16">
            <header>
              <p className="font-display text-[11px] font-medium tracking-[0.18em] text-[#D9BC7A]/70">{c.line} {line.code}</p>
              <h3 id={`linea-${line.code}`} className="mt-4 font-display text-[1.15rem] font-bold uppercase leading-snug tracking-[0.03em] text-[#D9BC7A]">
                {line.title}
              </h3>
              <p lang="en" className="mt-2 font-display text-[11px] font-medium uppercase tracking-[0.18em] text-stone-500">{line.en}</p>
              <p className="mt-5 font-display text-[15px] leading-relaxed text-stone-400">{line.desc}</p>
            </header>
            <ul className="grid content-start gap-x-12 gap-y-9 sm:grid-cols-2">
              {line.items.map(({ icon: Icon, title, desc }) => (
                <li key={title} className="flex gap-4">
                  <Icon className="mt-0.5 h-4 w-4 shrink-0 text-[#D9BC7A]/80" strokeWidth={1.25} aria-hidden />
                  <div>
                    <h4 className="font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-stone-100">{title}</h4>
                    <p className="mt-2 text-[14.5px] leading-relaxed text-stone-400">{desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  );
}
