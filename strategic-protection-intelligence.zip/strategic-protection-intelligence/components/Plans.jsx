"use client";
import { motion, useReducedMotion } from "framer-motion";
import { useLang } from "@/lib/i18n";
import { useQuote } from "./QuoteContext";
import LuxButton from "./LuxButton";

const SPRING = { type: "spring", stiffness: 100, damping: 20 };

export default function Plans() {
  const { t } = useLang();
  const { openRequest } = useQuote();
  const reduce = useReducedMotion();
  const c = t.plans;

  return (
    <section id="planes" aria-labelledby="planes-title" className="relative border-t border-white/5">
      <div className="mx-auto max-w-6xl px-5 py-24 sm:py-32">
        <p className="font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A]/80">{c.eyebrow}</p>
        <h2 id="planes-title" className="mt-5 max-w-3xl font-display text-[clamp(1.5rem,3.4vw,2.4rem)] font-bold uppercase leading-[1.15] tracking-[0.03em] text-stone-100">
          {c.title}
        </h2>
        <p className="mt-6 max-w-xl font-display text-[16px] leading-relaxed text-stone-400">{c.lead}</p>

        <ul className="mt-16 grid gap-px overflow-hidden rounded-md border border-white/5 bg-white/5 lg:grid-cols-3">
          {c.items.map((p, k) => (
            <motion.li
              key={p.id}
              initial={reduce ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ ...SPRING, delay: k * 0.08 }}
              className="group flex flex-col bg-[#050505] p-8 transition-colors duration-700 hover:bg-[#0a0907] sm:p-10"
            >
              <span className="font-display text-[11px] font-medium tracking-[0.18em] text-[#D9BC7A]/70">{String(k + 1).padStart(2, "0")}</span>
              <h3 className="mt-5 font-display text-[1.35rem] font-bold uppercase tracking-[0.03em] text-[#D9BC7A]">{p.name}</h3>
              <p className="mt-2 min-h-[2.9em] font-display text-[14px] leading-snug text-stone-400">{p.for}</p>

              <p className="mt-8 font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-stone-500">{c.includes}</p>
              <ul className="mt-4 flex-1 space-y-3">
                {p.includes.map((it) => (
                  <li key={it} className="flex items-start gap-3 font-display text-[14.5px] text-stone-200">
                    <span aria-hidden className="mt-[0.55em] h-[5px] w-[5px] shrink-0 rotate-45 bg-[#D9BC7A]/80" />
                    {it}
                  </li>
                ))}
              </ul>

              <LuxButton className="mt-10 w-full" onClick={() => openRequest("budget", p.id)}>
                {t.cta.budget}
              </LuxButton>
            </motion.li>
          ))}
        </ul>

        <p className="mt-10 text-center font-display text-[15px] text-stone-400">
          {c.custom}{" "}
          <button type="button" onClick={() => openRequest("budget")} className="font-semibold text-[#D9BC7A] underline-offset-[6px] hover:underline">
            {c.customCta}
          </button>
        </p>
      </div>
    </section>
  );
}
