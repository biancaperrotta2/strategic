"use client";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import LuxButton from "./LuxButton";
import { useQuote } from "./QuoteContext";
import LangToggle from "./LangToggle";
import { useLang } from "@/lib/i18n";
import { useIntroDone } from "@/lib/intro";

const SPRING = { type: "spring", stiffness: 100, damping: 20 };

/** Menú armado desde el contenido del idioma activo. */
function buildNav(t) {
  return [
    { id: "servicios", label: t.nav.services, href: "#servicios", note: t.nav.notes.services,
      items: t.services.lines.map(({ icon, title, en }) => ({ icon, title, desc: en })) },
    { id: "planes", label: t.nav.plans, href: "#planes" },
    { id: "metodologia", label: t.nav.method, href: "#metodologia", note: t.nav.notes.method, items: t.nav.methodItems },
    { id: "empresa", label: t.nav.company, href: "#empresa", note: t.nav.notes.company, items: t.nav.companyItems },
    { id: "contacto", label: t.nav.contact, href: "#contacto", wide: true },
  ];
}
const linkCls = "relative flex h-16 items-center font-display text-[11px] font-medium uppercase tracking-[0.18em] transition-colors duration-500";

function NavItem({ item, openId, setOpenId }) {
  const isOpen = openId === item.id;
  const hasPanel = !!item.items;
  const underline = isOpen && (
    <motion.span layoutId="nav-underline" aria-hidden className="absolute inset-x-0 bottom-[1.15rem] h-px bg-[#D4AF37]/60" transition={SPRING} />
  );
  return (
    <li onMouseEnter={() => setOpenId(hasPanel ? item.id : null)} className={item.wide ? "hidden xl:block" : undefined}>
      {hasPanel ? (
        <button
          type="button"
          aria-expanded={isOpen}
          aria-controls="nav-panel"
          onFocus={() => setOpenId(item.id)}
          onClick={() => setOpenId(isOpen ? null : item.id)}
          className={`${linkCls} ${isOpen ? "text-[#EADBB4]" : "text-stone-400 hover:text-stone-100"}`}
        >
          {item.label}
          {underline}
        </button>
      ) : (
        <a href={item.href} onFocus={() => setOpenId(null)} className={`${linkCls} text-stone-400 hover:text-stone-100`}>
          {item.label}
        </a>
      )}
    </li>
  );
}

export default function Navbar() {
  const { openQuote, openMeeting } = useQuote();
  const { t } = useLang();
  const NAV = buildNav(t);
  const LEFT = NAV.slice(0, 3);
  const RIGHT = NAV.slice(3);
  const [openId, setOpenId] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const [pastHero, setPastHero] = useState(false);
  const introDone = useIntroDone();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSection, setMobileSection] = useState(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      setPastHero(window.scrollY > window.innerHeight * 0.55);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e) => e.key === "Escape" && setMobileOpen(false);
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [mobileOpen]);

  const panel = NAV.find((n) => n.id === openId && n.items);
  const solid = scrolled || panel;

  return (
    <motion.header
      initial={{ opacity: 0, y: -8 }}
      animate={introDone ? { opacity: 1, y: 0 } : { opacity: 0, y: -8 }}
      transition={SPRING}
      // Mientras la intro corre, el menú no es interactivo ni enfocable.
      inert={introDone ? undefined : ""}
      className={`fixed inset-x-0 top-0 z-40 border-b pt-[env(safe-area-inset-top)] transition-[background-color,border-color] duration-700 ${
        solid ? "border-white/5 bg-[#030303]/85 backdrop-blur-md" : "border-transparent"
      }`}
    >
      <nav aria-label={t.nav.aria} className="relative" onMouseLeave={() => setOpenId(null)}>
        <div className="mx-auto grid h-16 max-w-7xl grid-cols-[1fr_auto_1fr] items-center px-5 lg:px-10">
          {/* Izquierda */}
          <div className="flex items-center">
            {/* Idioma siempre visible en móvil */}
            <LangToggle className="lg:hidden" />
            <ul className="hidden items-center gap-8 lg:flex">
              {LEFT.map((item) => <NavItem key={item.id} item={item} openId={openId} setOpenId={setOpenId} />)}
            </ul>
          </div>

          {/* Centro: la marca */}
          {/* La marca aparece al salir del hero: arriba ya la muestra el logo animado */}
          <a
            href="#inicio"
            onMouseEnter={() => setOpenId(null)}
            tabIndex={pastHero || mobileOpen ? 0 : -1}
            style={{ opacity: pastHero ? 1 : 0, transition: "opacity 700ms ease" }}
            className="px-6 font-display text-[1.05rem] font-extrabold tracking-[0.03em] text-[#D9BC7A] sm:text-[1.2rem]" aria-label={t.nav.home}>
            STRATEGIC
          </a>

          {/* Derecha */}
          <div className="flex items-center justify-end gap-8">
            <ul className="hidden items-center gap-8 lg:flex">
              {RIGHT.map((item) => <NavItem key={item.id} item={item} openId={openId} setOpenId={setOpenId} />)}
            </ul>
            <LangToggle className="hidden lg:flex" />
            <LuxButton size="sm" onClick={openMeeting} onMouseEnter={() => setOpenId(null)} className="hidden lg:inline-flex">
              {t.cta.meeting}
            </LuxButton>
            <button
              type="button"
              aria-label={t.nav.open}
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen(true)}
              className="flex h-10 w-10 items-center justify-center lg:hidden"
            >
              <Menu className="h-5 w-5 text-[#D9BC7A]" strokeWidth={1.25} aria-hidden />
            </button>
          </div>
        </div>

        {/* Panel desplegable por hover */}
        <AnimatePresence>
          {panel && (
            <motion.div
              id="nav-panel"
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4, transition: { duration: 0.2 } }}
              transition={SPRING}
              className="absolute inset-x-0 top-full hidden border-b border-white/5 bg-[#030303]/95 backdrop-blur-md lg:block"
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={panel.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="mx-auto grid max-w-7xl grid-cols-[1fr_17rem] gap-16 px-10 py-10"
                >
                  <ul className="grid grid-cols-2 gap-x-16 gap-y-8">
                    {panel.items.map(({ icon: Icon, title, desc }, k) => (
                      <motion.li key={title} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ ...SPRING, delay: 0.05 * k }}>
                        <a href={panel.href} onClick={() => setOpenId(null)} className="group flex gap-4">
                          <Icon className="mt-0.5 h-4 w-4 shrink-0 text-[#D9BC7A]/70 transition-colors duration-500 group-hover:text-[#D9BC7A]" strokeWidth={1.25} aria-hidden />
                          <span>
                            <span className="block font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-stone-200 transition-colors duration-500 group-hover:text-white">{title}</span>
                            <span className="mt-2 block font-display text-[14.5px] leading-snug text-stone-500">{desc}</span>
                          </span>
                        </a>
                      </motion.li>
                    ))}
                  </ul>
                  <div className="flex flex-col justify-between border-l border-white/5 pl-10">
                    <p className="font-display text-[17px] leading-snug text-stone-300">{panel.note}</p>
                    <button type="button" onClick={() => { setOpenId(null); openQuote(); }} className="mt-6 self-start font-display text-[11px] font-medium uppercase tracking-[0.18em] text-[#D9BC7A] underline-offset-[6px] hover:underline">
                      {t.cta.evaluate}
                    </button>
                  </div>
                </motion.div>
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Móvil */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileOpen(false)} />
            <motion.aside
              aria-label={t.nav.menu}
              className="fixed inset-y-0 right-0 z-50 flex w-[min(22rem,88vw)] flex-col border-l border-white/5 bg-[#030303]/85 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-[calc(1rem+env(safe-area-inset-top))] backdrop-blur-md lg:hidden"
              initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 32 }}
            >
              <div className="flex items-center justify-between px-6">
                <span className="font-display text-[1.05rem] font-extrabold tracking-[0.03em] text-[#D9BC7A]">STRATEGIC</span>
                <button type="button" aria-label={t.nav.close} onClick={() => setMobileOpen(false)} className="flex h-10 w-10 items-center justify-center">
                  <X className="h-5 w-5 text-stone-300" strokeWidth={1.25} aria-hidden />
                </button>
              </div>
              <ul className="mt-8 flex-1 overflow-y-auto px-6">
                {NAV.map((item) => {
                  const expanded = mobileSection === item.id;
                  const row = "flex w-full items-center justify-between py-5 font-display text-[11px] font-medium uppercase tracking-[0.18em] text-stone-200";
                  return (
                    <li key={item.id} className="border-b border-white/5">
                      {item.items ? (
                        <>
                          <button type="button" aria-expanded={expanded} onClick={() => setMobileSection(expanded ? null : item.id)} className={row}>
                            {item.label}
                            <span aria-hidden className="text-[#D9BC7A]">{expanded ? "−" : "+"}</span>
                          </button>
                          <AnimatePresence initial={false}>
                            {expanded && (
                              <motion.ul initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={SPRING} className="overflow-hidden">
                                {item.items.map(({ title }) => (
                                  <li key={title}>
                                    <a href={item.href} onClick={() => setMobileOpen(false)} className="block py-2.5 font-display text-[15px] text-stone-400">{title}</a>
                                  </li>
                                ))}
                                <li className="h-4" />
                              </motion.ul>
                            )}
                          </AnimatePresence>
                        </>
                      ) : (
                        <a href={item.href} onClick={() => setMobileOpen(false)} className={row}>{item.label}</a>
                      )}
                    </li>
                  );
                })}
              </ul>
              <div className="px-6 pt-4">
                <LuxButton className="w-full" onClick={() => { setMobileOpen(false); openMeeting(); }}>{t.cta.meeting}</LuxButton>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
