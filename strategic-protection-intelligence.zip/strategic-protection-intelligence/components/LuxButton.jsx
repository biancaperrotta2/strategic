"use client";
import { motion } from "framer-motion";

/** Botón glass: fondo translúcido, filete dorado satinado, hover suave. */
export default function LuxButton({ children, size = "md", className = "", ...props }) {
  const sizes = size === "sm" ? "h-9 px-5 text-[10px]" : "h-12 px-9 text-[11px]";
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.98 }}
      className={`inline-flex items-center justify-center gap-2.5 rounded-[2px] border border-[#D4AF37]/30 bg-white/5 font-display font-semibold uppercase tracking-[0.16em] text-[#EADBB4] backdrop-blur-md transition-[background-color,border-color,color] duration-500 hover:border-[#D4AF37]/60 hover:bg-[#D4AF37]/[0.08] hover:text-white ${sizes} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}
